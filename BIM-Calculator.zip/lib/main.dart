import 'package:flutter/material.dart';

void main() => runApp(const GradeCalculatorApp());

class GradeCalculatorApp extends StatelessWidget {
  const GradeCalculatorApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Grade Calculator',
      theme: ThemeData(
        primarySwatch: Colors.blueGrey,
        visualDensity: VisualDensity.adaptivePlatformDensity,
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.blueGrey,
          foregroundColor: Colors.white,
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.blueGrey,
            foregroundColor: Colors.white,
          ),
        ),
      ),
      home: const GradeCalculator(),
    );
  }
}

class GradeCalculator extends StatefulWidget {
  const GradeCalculator({super.key});

  @override
  State<GradeCalculator> createState() => _GradeCalculatorState();
}

class _GradeCalculatorState extends State<GradeCalculator> {
  // DATA_MODEL
  final TextEditingController _score1Controller = TextEditingController();
  final TextEditingController _score2Controller = TextEditingController();
  final TextEditingController _score3Controller = TextEditingController();
  final TextEditingController _score4Controller = TextEditingController();
  final TextEditingController _score5Controller = TextEditingController();

  String _result = "";
  Color _resultColor = Color(0xffff1101); // Added for conditional coloring

  @override
  void dispose() {
    _score1Controller.dispose();
    _score2Controller.dispose();
    _score3Controller.dispose();
    _score4Controller.dispose();
    _score5Controller.dispose();
    super.dispose();
  }

  void _calculateGrade() {
    final double? score1 = double.tryParse(_score1Controller.text);
    final double? score2 = double.tryParse(_score2Controller.text);
    final double? score3 = double.tryParse(_score3Controller.text);
    final double? score4 = double.tryParse(_score4Controller.text);
    final double? score5 = double.tryParse(_score5Controller.text);

    if (score1 != null &&
        score2 != null &&
        score3 != null &&
        score4 != null &&
        score5 != null &&
        score1 >= 0 &&
        score2 >= 0 &&
        score3 >= 0 &&
        score4 >= 0 &&
        score5 >= 0) {
      final double totalScore = score1 + score2 + score3 + score4 + score5;
      String grade;
      Color newResultColor;

      // New grading scale with increased granularity
      if (totalScore >= 80) {
        grade = "A";
        newResultColor = Colors.green;
      } else if (totalScore >= 75) {
        grade = "B+";
        newResultColor = Colors.lightGreen;
      } else if (totalScore >= 70) {
        grade = "B";
        newResultColor = Colors.lightGreen;
      } else if (totalScore >= 65) {
        grade = "C+";
        newResultColor = Colors.blue;
      } else if (totalScore >= 60) {
        grade = "C";
        newResultColor = Colors.blue;
      } else if (totalScore >= 55) {
        grade = "D+";
        newResultColor = Colors.amber.shade700; // Yellow for D+
      } else if (totalScore >= 50) {
        grade = "D";
        newResultColor = Colors.amber.shade700; // Yellow for D
      } else {
        grade = "F";
        newResultColor = Colors.red; // Red for F
      }

      setState(() {
        _result =
            "คะแนนรวม: ${totalScore.toStringAsFixed(2)}\nเกรดที่ได้: $grade";
        _resultColor = newResultColor;
      });
    } else {
      setState(() {
        _result = "กรุณากรอกคะแนนให้ถูกต้องและไม่ติดลบ";
        _resultColor = Colors.red; // Error message in red
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("เครื่องคำนวณเกรด"),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              TextField(
                controller: _score1Controller,
                keyboardType:
                    const TextInputType.numberWithOptions(decimal: true),
                decoration: const InputDecoration(
                  labelText: "เข้าเรียนและการมีส่วนร่วมในชั้นเรียน (5 %)",
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.school),
                ),
              ),
              const SizedBox(height: 15),
              TextField(
                controller: _score2Controller,
                keyboardType:
                    const TextInputType.numberWithOptions(decimal: true),
                decoration: const InputDecoration(
                  labelText: "งานมอบหมาย (30 %)",
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.assignment),
                ),
              ),
              const SizedBox(height: 15),
              TextField(
                controller: _score3Controller,
                keyboardType:
                    const TextInputType.numberWithOptions(decimal: true),
                decoration: const InputDecoration(
                  labelText: "โปรเจ็คกลุ่มและการนำเสนอ (15 %)",
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.group_work),
                ),
              ),
              const SizedBox(height: 15),
              TextField(
                controller: _score4Controller,
                keyboardType:
                    const TextInputType.numberWithOptions(decimal: true),
                decoration: const InputDecoration(
                  labelText: "สอบกลางภาค (25 %)",
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.menu_book),
                ),
              ),
              const SizedBox(height: 15),
              TextField(
                controller: _score5Controller,
                keyboardType:
                    const TextInputType.numberWithOptions(decimal: true),
                decoration: const InputDecoration(
                  labelText: "สอบปฏิบัติ (25 %)",
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.edit_note),
                ),
              ),
              const SizedBox(height: 30),
              ElevatedButton.icon(
                onPressed: _calculateGrade,
                icon: const Icon(Icons.calculate),
                label: const Text(
                  "คำนวณเกรด",
                  style: TextStyle(fontSize: 18),
                ),
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 15),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
              ),
              const SizedBox(height: 30),
              Text(
                _result,
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  color: _resultColor, // Apply the conditional color
                ),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
