package com.example.bim_calculator

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
